﻿   <!--footer section start-->
        <footer class="sticky-footer"> 2014 &copy; <a href="http://www.hapconsulting.net" target="_new">HAP Consulting.net</a></footer>
        <!--footer section end-->
        
          